WOHNWAGENCHECK – WEB-APP (iPhone)

1) Du brauchst einen Link im Internet (Hosting)
   - Kostenlos: GitHub Pages oder Netlify.
   - Lade den Inhalt dieses Ordners hoch.

2) Auf dem iPhone als App nutzen
   - Link in Safari öffnen
   - Teilen → „Zum Home-Bildschirm“ → Hinzufügen

3) Eigene Daten
   - data/models.json bearbeiten ODER in der App „Daten importieren“.
   - Format: Array von Modellen (siehe models.json).

Hinweis: Offline-Funktion klappt nur über HTTPS (GitHub Pages/Netlify machen das automatisch).
