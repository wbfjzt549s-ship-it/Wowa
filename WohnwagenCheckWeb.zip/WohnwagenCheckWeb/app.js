const $=s=>document.querySelector(s);
const S={models:[],filtered:[],sel:null};

const norm=s=>(s??"").toString().toLowerCase()
  .normalize("NFD").replace(/\p{Diacritic}/gu,"")
  .replace(/\s+/g," ").trim();

const esc=s=>(s??"").toString()
  .replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;")
  .replaceAll('"',"&quot;").replaceAll("'","&#039;");

const yearTxt=m=>{
  const a=m.yearFrom??null,b=m.yearTo??null;
  if(a&&b&&a!==b) return `${a}–${b}`;
  if(a) return `${a}`;
  return "n/a";
};

const fmt=(v,u)=> (v===null||v===undefined||v==="") ? "–" : `${v}${u?` ${u}`:""}`;

function kv(k,v){
  return `<div class="kvRow"><div class="k">${esc(k)}</div><div class="v">${esc(v??"–")}</div></div>`;
}
function li(t){ return `<li>${esc(t)}</li>`; }

function issueHTML(i){
  const badge=i.typicality?`<span class="badge">${esc(i.typicality)}</span>`:"";
  const yr=i.yearRange?`<div class="itemMeta">Baujahre: ${esc(i.yearRange)}</div>`:"";
  const symptoms=(i.symptoms||[]).length
    ? `<div class="itemMeta" style="margin-top:6px"><b>Anzeichen</b></div><ul>${(i.symptoms||[]).map(li).join("")}</ul>` : "";
  const tips=(i.checkTips||[]).length
    ? `<div class="itemMeta" style="margin-top:6px"><b>Check</b></div><ul>${(i.checkTips||[]).map(li).join("")}</ul>` : "";
  const notes=i.notes?`<div class="itemMeta" style="margin-top:6px">${esc(i.notes)}</div>`:"";
  return `<div class="issue">
    <div><b>${esc(i.title??"Problem")}</b>${badge}</div>
    <div class="itemMeta">${esc(i.category??"Allgemein")}</div>
    ${yr}${symptoms}${tips}${notes}
  </div>`;
}

function renderList(){
  const el=$("#list");
  el.innerHTML="";
  $("#count").textContent=S.filtered.length;
  if(!S.filtered.length){
    el.innerHTML='<div class="empty"><div class="emptyIcon">🗂️</div><div>Keine Treffer.</div></div>';
    return;
  }
  for(const m of S.filtered){
    const d=document.createElement("div");
    d.className="item"+(m.id===S.sel?" active":"");
    d.tabIndex=0;
    d.innerHTML=`<div class="itemTop">
      <div class="itemTitle">${esc(m.brand)} ${esc(m.model)}</div>
      <div class="itemMeta">${esc(yearTxt(m))}</div>
    </div>
    <div class="itemMeta">${esc(m.specs?.layout??"")}</div>`;
    d.onclick=()=>select(m.id);
    d.onkeydown=e=>{ if(e.key==="Enter"||e.key===" ") select(m.id); };
    el.appendChild(d);
  }
}

function renderDetail(){
  const el=$("#detail");
  const m=S.models.find(x=>x.id===S.sel);
  if(!m){
    el.innerHTML='<div class="empty"><div class="emptyIcon">🔎</div><div>Suche ein Modell aus der Liste.</div></div>';
    return;
  }
  const s=m.specs||{};
  const issues=Array.isArray(m.issues)?m.issues:[];
  el.innerHTML=`<div>
    <div class="itemTitle" style="font-size:18px">
      ${esc(m.brand)} ${esc(m.model)} <span class="itemMeta">${esc(yearTxt(m))}</span>
    </div>

    <div class="sectionTitle">Daten</div>
    <div class="kv">
      ${kv("Grundriss", s.layout)}
      ${kv("Schlafplätze", s.sleepingPlaces)}
      ${kv("Länge", fmt(s.lengthMm,"mm"))}
      ${kv("Breite", fmt(s.widthMm,"mm"))}
      ${kv("Höhe", fmt(s.heightMm,"mm"))}
      ${kv("zGG (MTPLM)", fmt(s.mtplmKg,"kg"))}
      ${kv("Zuladung", fmt(s.payloadKg,"kg"))}
    </div>

    <div class="sectionTitle">Typische Mängel / Probleme</div>
    ${issues.length ? issues.map(issueHTML).join("") : '<div class="muted" style="margin-top:8px">Keine Daten vorhanden.</div>'}
  </div>`;
}

function applySearch(){
  const q=norm($("#search").value);
  S.filtered = !q ? S.models.slice() : S.models.filter(m=>{
    const hay=norm(`${m.brand} ${m.model} ${m.yearFrom??""} ${m.yearTo??""} ${m.specs?.layout??""}`);
    return hay.includes(q);
  });
  if(S.sel && !S.filtered.find(x=>x.id===S.sel)) S.sel=null;
  renderList(); renderDetail();
}

function select(id){ S.sel=id; renderList(); renderDetail(); }

async function loadDefault(){
  const r=await fetch("data/models.json",{cache:"no-store"});
  if(!r.ok) throw new Error("models.json konnte nicht geladen werden");
  const data=await r.json();
  if(!Array.isArray(data)) throw new Error("models.json muss ein Array sein");
  S.models=data; S.filtered=data.slice();
  renderList(); renderDetail();
}

function download(name,text){
  const a=document.createElement("a");
  a.href=URL.createObjectURL(new Blob([text],{type:"application/json"}));
  a.download=name; a.click();
  setTimeout(()=>URL.revokeObjectURL(a.href),5000);
}

function setupUI(){
  $("#search").addEventListener("input", applySearch);
  $("#btnAbout").onclick=()=>$("#about").showModal();
  $("#btnExport").onclick=()=>download("models-export.json", JSON.stringify(S.models,null,2));
  $("#btnImport").onclick=()=>$("#file").click();
  $("#file").addEventListener("change", async(e)=>{
    const f=e.target.files?.[0]; if(!f) return;
    try{
      const data=JSON.parse(await f.text());
      if(!Array.isArray(data)) throw new Error("JSON muss ein Array sein");
      S.models=data; $("#search").value=""; applySearch();
      alert("Import erfolgreich.");
    } catch(err){ alert("Import fehlgeschlagen: "+err.message); }
    finally{ $("#file").value=""; }
  });
}

function setupSW(){
  if(!("serviceWorker" in navigator)) return;
  window.addEventListener("load", ()=>navigator.serviceWorker.register("sw.js").catch(()=>{}));
}

setupUI(); setupSW();
loadDefault().catch(()=>$("#list").innerHTML='<div class="empty"><div class="emptyIcon">⚠️</div><div>Daten konnten nicht geladen werden.</div></div>');
